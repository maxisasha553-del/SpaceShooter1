using Godot;
using System;

public partial class Астероид : Area2D

{
	const float СКОРОСТЬ=100.0f;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Position+=Vector2.Left*СКОРОСТЬ*(float)delta;
		if(Position.X<=-8)
		QueueFree();

	}
}
