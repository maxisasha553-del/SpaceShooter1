using Godot;
using System;

public partial class Выстрел : Area2D
{
	const int ЭКРАН_ШИРИНА=320;
	const double СКОРОСТЬ=500.0;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		this.Position+=new Vector2((float)(СКОРОСТЬ*delta), 0.0f);
		if (this.Position.X >= ЭКРАН_ШИРИНА+8)
		this.QueueFree(); //Уничтожение узла вместе со всеми дочерними
	}
}
