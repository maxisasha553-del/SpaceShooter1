using Godot;
using System;

public partial class Уровень : Node2D
{
	[Export]
	Sprite2D Фон;
	[Export]
	Timer таймер;
	[Export]
	PackedScene сценаМетиора;	
	Random случайнаяВеличина;


	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		случайнаяВеличина=new Random();
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Фон.Position+=Vector2.Left;
		if(Фон.Position.X<=0)
		Фон.Position=new Vector2(320,90);
	}
	public void ПоявлениеАстероидов()
	{
		var метиор=сценаМетиора.Instantiate();
		(метиор as Node2D).Position=new Vector2(320,случайнаяВеличина.Next(8,172));
		AddChild(метиор);
	}
}
