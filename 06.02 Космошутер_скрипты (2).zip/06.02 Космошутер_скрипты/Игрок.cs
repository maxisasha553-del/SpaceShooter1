using Godot;
using System;

public partial class Игрок : Area2D
{
	const double СКОРОСТЬ=150.0; //скорость в пикселях в секунду

	//Переменные для ограничения движения
	const int ЭКРАН_ШИРИНА=320;
	const int ЭКРАН_ВЫСОТА=180;

	//переменная сцены с выстрелом
	[Export]
	PackedScene СНАРЯД;

	//переменные для перезарядки
	[Export]
	Timer таймер;
	bool перезаряжен=true;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		ДВИЖ(delta);
		ДВИЖ_ЛИМИТ();
		ВЫСТРЕЛ();
	}
	//Код движения космического корабля
	public void ДВИЖ(double delta)
	{
		Vector2 ввод_курс = new Vector2();
		if (Input.IsActionPressed("ДВИЖ_ВВЕРХ"))
		ввод_курс.Y-=1.0f;
		if (Input.IsActionPressed("ДВИЖ_ВНИЗ"))
		ввод_курс.Y+=1.0f;
		if (Input.IsActionPressed("ДВИЖ_ВЛЕВО"))
		ввод_курс.X-=1.0f;
		if (Input.IsActionPressed("ДВИЖ_ВПРАВО"))
		ввод_курс.X+=1.0f;		

		//Передача в параметр позиции.
		this.Position+=(float)(delta*СКОРОСТЬ)*ввод_курс; //this - можно опустить
	}
	//Код движения космического корабля с ограничением
	public void ДВИЖ_ЛИМИТ()
	{
		if (this.Position.X<0.0f+8.0f)
		this.Position=new Vector2 (0.0f+8.0f, this.Position.Y);
		else if (this.Position.X>ЭКРАН_ШИРИНА-8.0f)
		this.Position=new Vector2 (ЭКРАН_ШИРИНА-8.0f, this.Position.Y);
		if (this.Position.Y<0.0f+8.0f)
		this.Position=new Vector2 (this.Position.X, 0.0f+8.0f);
		else if (this.Position.Y>ЭКРАН_ВЫСОТА-8.0f)
		this.Position=new Vector2 (this.Position.X, ЭКРАН_ВЫСОТА-8.0f);
	}
	//Код выстрела
	public void ВЫСТРЕЛ()
	{
		if (Input.IsActionPressed("ВЫСТРЕЛ") && перезаряжен)
		{
			перезаряжен=false;
			Node сцена = GetParent(); //получаем переменную, в которую записана информация о родительском узле текущей сцены
			таймер.Start();
			Node2D снаряд_экземпляр = СНАРЯД.Instantiate() as Node2D; //создаём экземпляр снаряда
			снаряд_экземпляр.Position = this.Position; 
			сцена.AddChild(снаряд_экземпляр); //инициируем экземпляр снаряда в сцену
		}
	}
	//Код срабатываниня таймера
	public void Истёк_таймер_перезарядки()
	{
		перезаряжен=true;
	}
}
